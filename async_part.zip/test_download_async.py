"""Проверки на локальном HTTP-сервере. Запросов к wiki-atp здесь нет."""

import asyncio
import logging
import os
import socket
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

import aiohttp
from aiohttp import web

import download_async as downloader


class DownloadTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.directory = Path(self.temporary.name)
        self.starts = []

        app = web.Application()
        app.router.add_get('/{path:.*}', self.handle_request)
        self.runner = web.AppRunner(app)
        await self.runner.setup()
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.bind(('127.0.0.1', 0))
        sock.setblocking(False)
        self.base_url = f'http://127.0.0.1:{sock.getsockname()[1]}'
        self.site = web.SockSite(self.runner, sock)
        await self.site.start()

    async def asyncTearDown(self):
        await self.runner.cleanup()
        self.temporary.cleanup()

    async def handle_request(self, request):
        self.starts.append(time.perf_counter())
        if request.path.startswith('/benchmark'):
            await asyncio.sleep(0.15)
        if request.path == '/slow':
            await asyncio.sleep(0.3)
        if request.path == '/http-error':
            return web.Response(status=503, text='Temporary error')
        return web.Response(text='<html><body>Привет</body></html>', content_type='text/html')

    async def run_downloads(self, adresses, workers=3, pause=0.05, timeout=1.0, folder='pages'):
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=timeout)) as session:
            return await downloader.download_courses_pages_async(
                session, adresses, downloader.RequestLimiter(pause),
                workers=workers, output_dir=self.directory / folder
            )

    async def test_global_pause_and_utf8(self):
        adresses = {f'{self.base_url}/ok/{i}': f'Тест/курс_{i}' for i in range(4)}
        result = await self.run_downloads(adresses, pause=0.08)
        self.assertEqual(result, {'saved': 4, 'skipped': 0, 'failed': 0})
        self.assertEqual(len(self.starts), 4)
        gaps = [right - left for left, right in zip(self.starts, self.starts[1:])]
        self.assertGreaterEqual(min(gaps), 0.06)
        page = self.directory / 'pages' / 'Тест_курс_0.html'
        self.assertIn('Привет', page.read_text(encoding='utf-8'))

    async def test_cache_and_empty_file(self):
        adresses = {f'{self.base_url}/ok/{i}': f'course_{i}' for i in range(2)}
        await self.run_downloads(adresses)
        request_count = len(self.starts)
        result = await self.run_downloads(adresses)
        self.assertEqual(result, {'saved': 0, 'skipped': 2, 'failed': 0})
        self.assertEqual(len(self.starts), request_count)

        (self.directory / 'pages' / 'empty.html').write_text('', encoding='utf-8')
        result = await self.run_downloads({f'{self.base_url}/empty': 'empty'})
        self.assertEqual(result['saved'], 1)

    async def test_http_error_timeout_and_remaining_jobs(self):
        adresses = {
            f'{self.base_url}/http-error': 'http_error',
            f'{self.base_url}/slow': 'timeout',
            f'{self.base_url}/ok': 'success',
        }
        with self.assertLogs(downloader.logger.name, level=logging.ERROR):
            result = await asyncio.wait_for(
                self.run_downloads(adresses, pause=0.01, timeout=0.07), timeout=3
            )
        self.assertEqual(result, {'saved': 1, 'skipped': 0, 'failed': 2})
        self.assertTrue((self.directory / 'pages' / 'success.html').is_file())
        self.assertFalse((self.directory / 'pages' / 'timeout.html').exists())
        self.assertFalse(list((self.directory / 'pages').glob('*.part')))

    async def test_failed_write_is_not_cached(self):
        original_replace = Path.replace

        def replace(path, target):
            if path.name == 'bad.html.part':
                raise OSError('Simulated write failure')
            return original_replace(path, target)

        adresses = {f'{self.base_url}/bad': 'bad', f'{self.base_url}/good': 'good'}
        with patch.object(Path, 'replace', new=replace):
            with self.assertLogs(downloader.logger.name, level=logging.ERROR):
                result = await self.run_downloads(adresses)
        self.assertEqual(result, {'saved': 1, 'skipped': 0, 'failed': 1})
        self.assertFalse((self.directory / 'pages' / 'bad.html').exists())
        self.assertFalse(list((self.directory / 'pages').glob('*.part')))

    async def test_empty_queue_and_invalid_worker_count(self):
        result = await self.run_downloads({})
        self.assertEqual(result, {'saved': 0, 'skipped': 0, 'failed': 0})
        self.assertFalse(self.starts)
        with self.assertRaises(ValueError):
            await self.run_downloads({}, workers=0)

    async def test_overlapping_requests_are_faster(self):
        adresses = {f'{self.base_url}/benchmark/{i}': f'course_{i}' for i in range(8)}
        started = time.perf_counter()
        sequential_result = await self.run_downloads(adresses, workers=1, pause=0.06, folder='one')
        sequential = time.perf_counter() - started
        started = time.perf_counter()
        parallel_result = await self.run_downloads(adresses, workers=3, pause=0.06, folder='three')
        parallel = time.perf_counter() - started
        self.assertEqual(sequential_result['saved'], 8)
        self.assertEqual(parallel_result['saved'], 8)
        self.assertLess(parallel, sequential * 0.9)
        print(
            f'\nЛокальный замер: 1 работник — {sequential:.3f} с, '
            f'3 работника — {parallel:.3f} с, ускорение {sequential / parallel:.2f} раза.'
        )

    async def test_main_with_complete_cache_makes_no_requests(self):
        wiki_path = Path(__file__).resolve().with_name('wiki.html')
        if not wiki_path.is_file():
            self.skipTest('Для этой проверки нужен сохранённый wiki.html рядом со скриптом')
        wiki_text = wiki_path.read_text(encoding='utf-8')
        original_directory = Path.cwd()
        try:
            os.chdir(self.directory)
            Path('wiki.html').write_text(wiki_text, encoding='utf-8')
            adresses = downloader.collect_saved_courses()
            self.assertTrue(adresses)
            Path('courses_2025_2026').mkdir()
            for name in adresses.values():
                filename = name.replace('/', '_')
                Path(f'courses_2025_2026/{filename}.html').write_text('<html>cache</html>', encoding='utf-8')
            with patch.object(aiohttp.ClientSession, 'get', side_effect=AssertionError('Network is forbidden in cache test')) as get:
                result = await downloader.main()
            self.assertTrue(result)
            get.assert_not_called()
            print(f'Проверка полного кэша: {len(adresses)} страниц, HTTP-запросов 0.')
        finally:
            os.chdir(original_directory)

    async def test_main_logs_index_parsing_error(self):
        original_directory = Path.cwd()
        try:
            os.chdir(self.directory)
            Path('wiki.html').write_text('<html>Wrong page</html>', encoding='utf-8')
            with patch.object(aiohttp.ClientSession, 'get') as get:
                with self.assertLogs(downloader.logger.name, level=logging.ERROR):
                    result = await downloader.main()
            self.assertFalse(result)
            get.assert_not_called()
        finally:
            os.chdir(original_directory)


if __name__ == '__main__':
    unittest.main(verbosity=2)
