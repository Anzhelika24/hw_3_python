import asyncio
import logging
import sys
import time
from pathlib import Path

import aiohttp
from bs4 import BeautifulSoup

from download import collect_courses, take_unique_adresses


DOMAIN = 'https://wiki.atp-fivt.org/'
WORKERS = 3
REQUEST_PAUSE = 2.0
REQUEST_TIMEOUT = 10.0

logger = logging.getLogger(__name__)


class RequestLimiter:
    """Общая пауза между началами запросов всех работников."""

    def __init__(self, pause):
        if pause < 0:
            raise ValueError('Пауза не может быть отрицательной')
        self.pause = pause
        self.lock = asyncio.Lock()
        self.next_request_at = 0.0

    async def wait(self):
        async with self.lock:
            loop = asyncio.get_running_loop()
            delay = self.next_request_at - loop.time()
            if delay > 0:
                await asyncio.sleep(delay)
            self.next_request_at = loop.time() + self.pause


def save_html(file_path, text):
    # Незавершённая запись не должна выглядеть как готовый HTML.
    temporary_path = Path(f'{file_path}.part')
    try:
        with open(temporary_path, 'w', encoding='utf-8') as file:
            file.write(text)
        temporary_path.replace(file_path)
    finally:
        temporary_path.unlink(missing_ok=True)


async def download_page_async(session, url, filename, limiter):
    file_path = Path(f'{filename}.html')

    try:
        if file_path.is_file() and file_path.stat().st_size > 0:
            logger.info('Уже сохранена: %s', file_path)
            return 'skipped'

        await limiter.wait()
        logger.info('Запрос: %s', url)

        async with session.get(url) as response:
            response.raise_for_status()
            text = await response.text()

        await asyncio.to_thread(save_html, file_path, text)
        logger.info('Страница сохранена: %s', file_path)
        return 'saved'

    except (aiohttp.ClientError, asyncio.TimeoutError, OSError, UnicodeError):
        logger.exception('Не удалось скачать или сохранить %s', url)
        return 'failed'


async def worker(queue, session, limiter, output_dir, counts):
    while True:
        task = await queue.get()
        try:
            if task is None:
                return

            url, name = task
            safe_name = name.replace('/', '_')
            filename = f'{output_dir}/{safe_name}'
            result = await download_page_async(session, url, filename, limiter)
            counts[result] += 1

        except Exception:
            # Ошибка одного задания не оставляет очередь незавершённой.
            counts['failed'] += 1
            logger.exception('Ошибка обработки задания: %r', task)
        finally:
            queue.task_done()


async def download_courses_pages_async(
    session, adresses, limiter, workers=WORKERS,
    output_dir='courses_2025_2026'
):
    if workers < 1:
        raise ValueError('Нужен хотя бы один работник')

    Path(output_dir).mkdir(parents=True, exist_ok=True)
    queue = asyncio.Queue()
    counts = {'saved': 0, 'skipped': 0, 'failed': 0}

    for url, name in adresses.items():
        queue.put_nowait((url, name))
    for _ in range(workers):
        queue.put_nowait(None)

    tasks = [
        asyncio.create_task(worker(queue, session, limiter, output_dir, counts))
        for _ in range(workers)
    ]

    try:
        await queue.join()
        await asyncio.gather(*tasks)
    finally:
        for task in tasks:
            if not task.done():
                task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)

    return counts


def collect_saved_courses():
    with open('wiki.html', 'r', encoding='utf-8') as file:
        text = file.read()

    soup = BeautifulSoup(text, 'html.parser')
    courses = collect_courses(soup, DOMAIN)
    adresses = take_unique_adresses(courses)
    if not adresses:
        raise ValueError('В wiki.html не найдены ссылки на курсы 2025–2026 годов')
    return adresses


async def main():
    started = time.perf_counter()
    try:
        limiter = RequestLimiter(REQUEST_PAUSE)
        timeout = aiohttp.ClientTimeout(total=REQUEST_TIMEOUT)

        async with aiohttp.ClientSession(timeout=timeout) as session:
            result = await download_page_async(session, DOMAIN, 'wiki', limiter)
            if result == 'failed':
                return False

            # Чтение файла и BeautifulSoup не блокируют цикл событий.
            adresses = await asyncio.to_thread(collect_saved_courses)
            logger.info('Уникальных адресов: %d', len(adresses))
            counts = await download_courses_pages_async(session, adresses, limiter)

        logger.info(
            'Завершено: сохранено=%d, пропущено=%d, ошибок=%d',
            counts['saved'], counts['skipped'], counts['failed']
        )
        return counts['failed'] == 0

    except Exception:
        logger.exception('Не удалось завершить загрузку или разобрать главную страницу')
        return False
    finally:
        logger.info('Время выполнения: %.2f с', time.perf_counter() - started)


if __name__ == '__main__':
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s %(levelname)s %(message)s',
        handlers=[
            logging.FileHandler('download_async.log', encoding='utf-8'),
            logging.StreamHandler(),
        ],
    )
    success = asyncio.run(main())
    sys.exit(0 if success else 1)
